# IRIS 2027 Website Redesign (`iris2027-redesign-v5`)

Clean development version of the **IRIS 2027** redesign (Indian Institute of Management Indore).

## Summary of Refinements in v5
1. **`src/components/about/AboutStats.tsx`**:
   - Replaced claims that official figures "will be announced" or are undergoing committee confirmation with neutral wording: *"Official festival statistics are not currently available for publication."*
2. **`src/data/faqs.ts`**:
   - Moved *"How are event guidelines and participation policies communicated?"* out of `VERIFIED_FAQS` and into `PROVISIONAL_FAQ_TOPICS`.
