import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "IRIS 2027 | IIM Indore Annual Festival",
  description:
    "Official website for IRIS 2027, the cultural and management festival of the Indian Institute of Management Indore.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable}`}
    >
      <body className="bg-iris-black text-iris-white font-sans antialiased selection:bg-iris-magenta selection:text-iris-white">
        {children}
      </body>
    </html>
  );
}
