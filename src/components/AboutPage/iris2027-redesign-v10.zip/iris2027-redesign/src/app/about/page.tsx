import type { Metadata } from "next";
import { AboutHero } from "@/components/about/AboutHero";
import { AboutStory } from "@/components/about/AboutStory";
import { AboutStats } from "@/components/about/AboutStats";
import { CampusMapSection } from "@/components/campus-map/CampusMapSection";
import { FAQSection } from "@/components/faq/FAQSection";
import { SectionNav } from "@/components/shared/SectionNav";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export const metadata: Metadata = {
  title: "About IRIS 2027 | IIM Indore",
  description:
    "Discover IRIS 2027 at the Indian Institute of Management Indore — cultural and management dimensions, festival figures, campus map, and FAQs.",
};

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-iris-black text-iris-white relative selection:bg-iris-magenta selection:text-iris-white overflow-x-hidden pb-20">
      {/* Skip to Main Content for Keyboard Accessibility */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:px-4 focus:py-2 focus:rounded-lg focus:bg-iris-sky focus:text-iris-black focus:font-mono focus:text-xs focus:font-semibold"
      >
        Skip to main content
      </a>

      {/* Top Navigation Bar (Desktop & Mobile Responsive) */}
      <header className="fixed top-0 left-0 right-0 z-40 bg-iris-black/85 backdrop-blur-md border-b border-iris-sky/15 px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4">
        <Link
          href="/"
          className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-iris-sky hover:text-iris-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-iris-sky rounded-md px-1.5 py-1"
        >
          <ArrowLeft className="w-3.5 h-3.5 shrink-0" />
          <span>Home</span>
        </Link>

        {/* Quick Desktop Anchor Links */}
        <nav aria-label="Header section links" className="hidden md:flex items-center gap-6 text-xs font-mono text-iris-white/70">
          <a href="#about-iris" className="hover:text-iris-sky transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-iris-sky rounded px-1">
            About
          </a>
          <a href="#reference-stats" className="hover:text-iris-sky transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-iris-sky rounded px-1">
            Figures
          </a>
          <a href="#campus-map" className="hover:text-iris-sky transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-iris-sky rounded px-1">
            Campus Map
          </a>
          <a href="#faq" className="hover:text-iris-sky transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-iris-sky rounded px-1">
            FAQ
          </a>
        </nav>

        <div className="flex items-center gap-2.5">
          <span className="font-sans font-black tracking-widest text-sm text-iris-white">
            IRIS <span className="text-iris-sky font-normal font-saman">2027</span>
          </span>
          <span className="text-iris-sky/30 hidden sm:inline">|</span>
          <span className="font-mono text-xs text-iris-white/60 hidden sm:inline">
            IIM INDORE
          </span>
        </div>
      </header>

      {/* Floating Bottom Section Dock (Visible on both Mobile & Desktop) */}
      <SectionNav />

      {/* Main Content */}
      <main id="main-content">
        <div id="about-hero" className="scroll-mt-16">
          <AboutHero />
        </div>
        <AboutStory />
        <AboutStats />
        <CampusMapSection />
        <FAQSection />
      </main>

      {/* Footer */}
      <footer className="py-12 border-t border-iris-sky/15 text-center text-xs font-mono text-iris-white/50 space-y-2">
        <p>IRIS 2027 · INDIAN INSTITUTE OF MANAGEMENT INDORE</p>
      </footer>
    </div>
  );
}
