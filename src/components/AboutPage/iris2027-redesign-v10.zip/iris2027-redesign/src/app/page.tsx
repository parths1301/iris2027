import Link from "next/link";
import { ArrowRight, Compass, HelpCircle, Info } from "lucide-react";

export default function Home() {
  return (
    <main className="min-h-screen bg-iris-black flex flex-col justify-center items-center px-6 py-20 text-center relative overflow-hidden">
      <div className="absolute top-1/4 -left-40 w-96 h-96 bg-iris-purple/25 rounded-full blur-[128px] pointer-events-none" />
      <div className="absolute bottom-1/4 -right-40 w-96 h-96 bg-iris-navy/40 rounded-full blur-[128px] pointer-events-none" />

      <div className="max-w-2xl z-10 space-y-6">
        <span className="inline-block px-3.5 py-1 rounded-full text-xs font-mono tracking-widest uppercase bg-iris-navy text-iris-sky border border-iris-sky/30">
          IIM Indore · IRIS 2027
        </span>

        <h1 className="text-4xl sm:text-6xl font-black tracking-tight text-iris-white uppercase">
          IRIS <span className="font-saman text-iris-sky font-normal">2027</span>
        </h1>

        <p className="text-iris-white/75 text-base sm:text-lg leading-relaxed">
          Independent redesign workspace. Explore the About IRIS page, campus map architecture, and FAQ section.
        </p>

        <div className="pt-6 flex flex-wrap justify-center gap-4">
          <Link
            href="/about"
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-iris-magenta hover:bg-iris-magenta/90 text-iris-white font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-iris-sky"
          >
            <Info className="w-4 h-4" /> Explore About IRIS <ArrowRight className="w-4 h-4" />
          </Link>
          <Link
            href="/about#campus-map"
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-iris-navy/50 hover:bg-iris-navy text-iris-sky border border-iris-sky/25 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-iris-sky"
          >
            <Compass className="w-4 h-4" /> Campus Map
          </Link>
          <Link
            href="/about#faq"
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-iris-navy/50 hover:bg-iris-navy text-iris-sky border border-iris-sky/25 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-iris-sky"
          >
            <HelpCircle className="w-4 h-4" /> FAQs
          </Link>
        </div>
      </div>
    </main>
  );
}
